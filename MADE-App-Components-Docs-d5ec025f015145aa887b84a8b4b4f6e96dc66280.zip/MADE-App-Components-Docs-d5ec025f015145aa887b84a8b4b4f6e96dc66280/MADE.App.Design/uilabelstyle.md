# UILabelStyle class

> Namespace: MADE.App.Design.Styles

Defines the style model for an iOS UILabel.

```csharp
public class UILabelStyle : BaseStyle<UILabel>
```

## Supported platforms

| Platform | Version |
| --- | --- |
| Xamarin.iOS  | 1.0 |
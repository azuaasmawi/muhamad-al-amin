# MADE App Components

![](.gitbook/assets/projectbanner.png)

## What are MADE App Components?

MADE App Components is a collection of easy to use features aiming to make app development easier. It provides the building blocks for creating great user experiences on Windows (UWP), Android and iOS (Xamarin).
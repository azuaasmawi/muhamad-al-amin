# NSObjectExtensions class

> Namespace: MADE.App.Extensions

Defines a collection of extensions for iOS NSObject values.

```csharp
public static class NSObjectExtensions
```

## Supported platforms

| Platform | Version |
| --- | --- |
| Xamarin.iOS  | 1.0 |
# AssociationPolicy enum

> Namespace: MADE.App.Enums

Defines values to specify the behavior of an association.

```csharp
public enum AssociationPolicy
```

## Supported platforms

| Platform | Version |
| --- | --- |
| Xamarin.iOS  | 1.0 |